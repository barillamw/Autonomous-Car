//------------------------------------------------------------------------------
//
//  Description: This file contains the functions to interpret the Serial 
//  Communications fromt the PC
//  
//
//  Michael Barilla
//  Jan 2019
//  Built with IAR Embedded Workbench Version: V4.10A/W32 (7.11.2)
//------------------------------------------------------------------------------


#include  "functions.h"
#include  "msp430.h"
#include <string.h>
#include "macros.h"

  // Global Variables




