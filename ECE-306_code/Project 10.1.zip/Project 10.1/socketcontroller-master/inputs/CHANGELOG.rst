CHANGELOG
=========

0.5
---

* Gamepad Vibration support on Linux
* Microbit Gamepad support
* Support for system LEDs
* New Sphinx based Documentation
* JS test style example
* More Unit tests
* More hardware tested: PS3 Controller, PS4 Controller, Xbox One Controller
