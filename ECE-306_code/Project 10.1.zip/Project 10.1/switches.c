#include  "functions.h"
#include  "msp430.h"
#include "macros.h"


extern unsigned int time_change2;
extern unsigned char event;
extern unsigned char shape;

void Switches_Process(void){
if(
  //---------------------------------------------------------------------------
    }
  }
}